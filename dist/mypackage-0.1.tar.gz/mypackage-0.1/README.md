# mypackage
This Code was created as an example of how to create and publish a python package

# how to install
...